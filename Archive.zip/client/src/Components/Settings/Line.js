import './style/Settings.css';

const Line = () => {
   return (
      <div className='line'></div>
   )
}

export default Line;